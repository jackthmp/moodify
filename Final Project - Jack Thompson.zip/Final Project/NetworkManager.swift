//
//  NetworkManager.swift
//  
//
//  Created by Jack Thompson on 12/2/17.
//

import Foundation

import SwiftyJSON
import Alamofire
import SpotifyLogin


let hostURL = "https://api.spotify.com"

class NetworkManager{
    

    static var user:User!
    
    static func getPlaylists(completion: @escaping ([Playlist]) -> Void){
        guard let url = URL(string: hostURL + "/v1/me/playlists") else { return }
        let parameters:[String: Any] = ["limit": 50]
        
        SpotifyLogin.shared.getAccessToken { (code, error) in
            if (error == nil){
                Alamofire.request(url, method: .get, parameters: parameters, encoding: URLEncoding.default, headers: ["Authorization": "Bearer " + code!])
                    .validate().responseJSON{ response in
                    switch response.result {
                    case .success(let data):
                        let json = JSON(data)
                        var playlists:[Playlist] = []
                        let dispatchGroup = DispatchGroup()
                        let dispatchQueue = DispatchQueue(label: "playlistQueue")
                        let dispatchSemaphore = DispatchSemaphore(value: 0)
                        
                        dispatchQueue.async {
                            for playlist in json["items"].arrayValue {
                                if playlist["tracks"]["total"].intValue > 0 {
                                    dispatchGroup.enter()
                                    let currentPlaylist = Playlist(json:playlist)
                                    getTracks(userID: currentPlaylist.user, playlistID: currentPlaylist.id, completion: { (tracks) in
                                        currentPlaylist.tracks = tracks
                                        playlists.append(currentPlaylist)
                                        dispatchGroup.leave()
                                        dispatchSemaphore.signal()
                                        if playlist == json["items"].arrayValue[json["items"].arrayValue.count - 1] {
                                            completion(playlists)
                                        }
                                    })
                                    dispatchSemaphore.wait()
                                }
                            }
                        }
                    case .failure (let error):
                        print(error)
                    }
                }
            }
        }
    }
    
    static func getTracks(userID: String, playlistID: String, completion: @escaping ([Track]) -> Void){
        guard let url = URL(string: hostURL + "/v1/users/" + userID + "/playlists/" + playlistID) else { return }
        SpotifyLogin.shared.getAccessToken { (code, error) in
            if (error == nil){
                Alamofire.request(url, method: .get, parameters: nil, encoding: URLEncoding.default, headers: ["Authorization": "Bearer " + code!]).validate().responseJSON{ response in
                    switch response.result {
                    case .success(let data):
                        let json = JSON(data)
                        var tracks:[Track] = []
                        //print(json["tracks"]["items"])
                        for track in json["tracks"]["items"].arrayValue {
                            tracks.append(Track(json: track["track"]))
                        }
                        completion(tracks)
                    case .failure (let error):
                        print(error)
                        completion([])
                    }
                }
            }
        }
                
    }
                
    
    
    static func getUser(completion: @escaping (User) -> Void){
        guard let url = URL(string: hostURL + "/v1/me") else { return }
        SpotifyLogin.shared.getAccessToken { (code, error) in
            if (error == nil){
                Alamofire.request(url, method: .get, parameters: nil, encoding: URLEncoding.default, headers: ["Authorization": "Bearer " + code!])
                    .validate().responseJSON { response in
                    switch response.result {
                    case .success(let data):
                        let json = JSON(data)
                        let user = User(json: json)
                        self.user = user
                        completion(user)
                    case .failure (let error):
                        print(error)
                    }
                    
                }
            }
            else { print(error!) }
        }
    }
    
    static func getImage(url: String, completion: @escaping (UIImage) -> Void){
        if let imageURL = URL(string: url) {
            Alamofire.request(imageURL).validate().responseData { response in
                switch response.result {
                case .success(let data):
                    if let image = UIImage(data: data){
                        completion(image)
                    }
                    else {
                        print("Unable to convert data to image")
                        completion(#imageLiteral(resourceName: "Music-icon"))
                    }
                    
                case .failure(let error):
                    print(error)
                    completion(#imageLiteral(resourceName: "Music-icon"))
                }
            }
        }
        else { completion(#imageLiteral(resourceName: "Music-icon")) }
    }
    
    static func getTopTracks(userid: String, completion: @escaping ([Track]) -> Void){
        guard let url = URL(string: hostURL + "/v1/me/top/tracks") else { return }
        let parameters:[String: Any] = ["limit": 50,
                                        "time_range": "long_term"]
        var topTracks:[Track] = []
        
        SpotifyLogin.shared.getAccessToken { (code, error) in
            if (error == nil){
                Alamofire.request(url, method: .get, parameters: parameters, encoding: URLEncoding.default, headers: ["Authorization": "Bearer " + code!]).validate().responseData { response in
                    switch response.result {
                    case .success(let data):
                        let json = JSON(data)
                        for track in json["items"].arrayValue{
                            topTracks.append(Track(json: track))
                        }
                    case .failure(let error):
                        print(error)
                    }
                    completion(topTracks)
                }
            }
        }
    }
    
    static func analyzeTracks(tracks:[Track], completion: @escaping ([String: Float]) -> Void){
        var danceability:Float = 0.0
        var energy:Float = 0.0
        var instrumentalness:Float = 0.0
        var valence:Float = 0.0
        var acousticness:Float = 0.0
        var trackList = ""
        for track in tracks{
            trackList += track.id + ","
        }
        guard let url = URL(string: hostURL + "/v1/audio-features") else { return }
        let parameters:[String: Any] = ["ids": trackList]
        SpotifyLogin.shared.getAccessToken { (code, error) in
            if (error == nil){
                Alamofire.request(url, method: .get, parameters: parameters, encoding: URLEncoding.default, headers: ["Authorization": "Bearer " + code!]).validate().responseData { response in
                    switch response.result {
                    case .success(let data):
                        let json = JSON(data)
                        for track in json["audio_features"].arrayValue{
                            danceability += track["danceability"].floatValue
                            energy += track["energy"].floatValue
                            instrumentalness += track["instrumentalness"].floatValue
                            valence += track["valence"].floatValue
                            acousticness += track["acousticness"].floatValue
                        }
                        danceability = danceability / Float(json["audio_features"].arrayValue.count)
                        energy = energy / Float(json["audio_features"].arrayValue.count)
                        instrumentalness = instrumentalness / Float(json["audio_features"].arrayValue.count)
                        valence = valence / Float(json["audio_features"].arrayValue.count)
                        acousticness = acousticness / Float(json["audio_features"].arrayValue.count)
                        
                    case .failure(let error):
                        print(error)
                    }
                    
                    completion(["danceability" : danceability,
                                "energy" : energy,
                                "instrumentalness" : instrumentalness,
                                "valence" : valence,
                                "acousticness" : acousticness])
                }
        
            }
        }
    }
    
    static func createPlaylist(user: User, completion: @escaping (Playlist) -> Void){
        guard let url = URL(string: hostURL + "/v1/users/" + user.id + "/playlists/") else { return }
        let parameters:[String: Any] = ["description" : "", "public" : true, "name" : "Moodify Playlist"]
        SpotifyLogin.shared.getAccessToken { (code, error) in
            if (error == nil){
                Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default, headers: ["Authorization": "Bearer " + code!]).validate().responseJSON { response in
                    switch response.result {
                    case .success(let data):
                        let json = JSON(data)
                        let playlist = Playlist(json: json)
                        
                        completion(playlist)
                    case .failure(let error):
                        print(error.localizedDescription)
                    }
                }
            }
        }
    }
    
}

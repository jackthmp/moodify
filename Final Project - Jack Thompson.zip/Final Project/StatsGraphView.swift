//
//  StatsGraphView.swift
//  Final Project
//
//  Created by Jack Thompson on 12/10/17.
//  Copyright © 2017 Jack Thompson. All rights reserved.
//

import UIKit

class StatsGraphView: UIView {

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */
    
    var stats:[String: Float]!
    
    var energyBar:UIView!
    var moodBar:UIView!
    var danceBar:UIView!
    var acousticBar:UIView!
    var instrumentalBar:UIView!
    
    var isVertical:Bool!
    
    var padding:CGFloat = 20.0
    
    init(vertical: Bool, frame: CGRect) {
        super.init(frame: frame)
        self.isVertical = vertical
        
        energyBar = UIView()
        energyBar.backgroundColor = Constants.energyColor
        self.addSubview(energyBar)
        
        moodBar = UIView()
        moodBar.backgroundColor = Constants.moodColor
        self.addSubview(moodBar)
        
        danceBar = UIView()
        danceBar.backgroundColor = Constants.danceColor
        self.addSubview(danceBar)
        
        acousticBar = UIView()
        acousticBar.backgroundColor = Constants.acousticColor
        self.addSubview(acousticBar)
        
        instrumentalBar = UIView()
        instrumentalBar.backgroundColor = Constants.instrumentalColor
        self.addSubview(instrumentalBar)
        
        
        
    }
    
    func setBars(){
        if (isVertical == true) {
            
            energyBar.frame = CGRect(x: padding, y: frame.height, width: (frame.width - 2 * padding) / 5, height: 0)
            energyBar.growVertical(size: (frame.height*(CGFloat)(stats["energy"]!)))
        
            moodBar.frame = CGRect(x: energyBar.frame.maxX, y: frame.height, width: (frame.width - 2 * padding) / 5, height: 0)
            moodBar.growVertical(size: (frame.height*(CGFloat)(stats["valence"]!)))
        
            danceBar.frame = CGRect(x: moodBar.frame.maxX, y: frame.height, width: (frame.width - 2 * padding) / 5, height: 0)
            danceBar.growVertical(size: (frame.height*(CGFloat)(stats["danceability"]!)))
        
            acousticBar.frame = CGRect(x: danceBar.frame.maxX, y: frame.height, width: (frame.width - 2 * padding) / 5, height: 0)
            acousticBar.growVertical(size: (frame.height*(CGFloat)(stats["acousticness"]!)))
        
            instrumentalBar.frame = CGRect(x: acousticBar.frame.maxX, y: frame.height, width: (frame.width - 2 * padding) / 5, height: 0)
            instrumentalBar.growVertical(size: (frame.height*(CGFloat)(stats["instrumentalness"]!)))
        }
        else {
            
            let energyLabel:UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: 110, height: frame.height / 5))
            energyLabel.text = "Energy:"
            energyLabel.textAlignment = .right
            energyLabel.font = UIFont.systemFont(ofSize: 16, weight: .light)
            addSubview(energyLabel)
            
            energyBar.frame = CGRect(x: energyLabel.frame.maxX + padding/2, y: padding, width: 0, height: (frame.height - 4*padding) / 5)
            energyBar.center.y = energyLabel.center.y
            energyBar.growHorizontal(size: (frame.width - energyLabel.frame.maxX) * (CGFloat)(stats["energy"]!))
            
            let moodLabel:UILabel = UILabel(frame: CGRect(x: 0, y: energyLabel.frame.maxY, width: 110, height: frame.height / 5))
            moodLabel.text = "Mood:"
            moodLabel.textAlignment = .right
            moodLabel.font = UIFont.systemFont(ofSize: 16, weight: .light)
            addSubview(moodLabel)

            moodBar.frame = CGRect(x: moodLabel.frame.maxX + padding/2, y: energyBar.frame.maxY + padding , width: 0, height: (frame.height - 4*padding) / 5)
            moodBar.center.y = moodLabel.center.y
            moodBar.growHorizontal(size: (frame.width - energyLabel.frame.maxX) * (CGFloat)(stats["valence"]!))
            
            let danceLabel:UILabel = UILabel(frame: CGRect(x: 0, y: moodLabel.frame.maxY, width: 110, height: frame.height / 5))
            danceLabel.text = "Danceability:"
            danceLabel.textAlignment = .right
            danceLabel.font = UIFont.systemFont(ofSize: 16, weight: .light)
            addSubview(danceLabel)
            
            danceBar.frame = CGRect(x: danceLabel.frame.maxX + padding/2, y: moodBar.frame.maxY , width: 0, height: (frame.height - 4*padding) / 5)
            danceBar.center.y = danceLabel.center.y
            danceBar.growHorizontal(size: (frame.width - energyLabel.frame.maxX) * (CGFloat)(stats["danceability"]!))
            
            let acousticLabel:UILabel = UILabel(frame: CGRect(x: 0, y: danceLabel.frame.maxY, width: 110, height: frame.height / 5))
            acousticLabel.text = "Acousticness:"
            acousticLabel.textAlignment = .right
            acousticLabel.font = UIFont.systemFont(ofSize: 16, weight: .light)
            addSubview(acousticLabel)
            
            acousticBar.frame = CGRect(x: acousticLabel.frame.maxX + padding/2, y: danceBar.frame.maxY , width: 0, height: (frame.height - 4*padding) / 5)
            acousticBar.center.y = acousticLabel.center.y
            acousticBar.growHorizontal(size: (frame.width - energyLabel.frame.maxX) * (CGFloat)(stats["acousticness"]!))
            
            let instrumentalLabel:UILabel = UILabel(frame: CGRect(x: 0, y: acousticLabel.frame.maxY, width: 110, height: frame.height / 5))
            instrumentalLabel.text = "Instrumental:"
            instrumentalLabel.textAlignment = .right
            instrumentalLabel.font = UIFont.systemFont(ofSize: 16, weight: .light)
            addSubview(instrumentalLabel)
            
            instrumentalBar.frame = CGRect(x: danceLabel.frame.maxX + padding/2, y: acousticBar.frame.maxY , width: 0, height: (frame.height - 4*padding) / 5)
            instrumentalBar.center.y = instrumentalLabel.center.y
            instrumentalBar.growHorizontal(size: (frame.width - energyLabel.frame.maxX) * (CGFloat)(stats["instrumentalness"]!))
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

public extension UIView {
    
    func growHorizontal(withDuration duration: TimeInterval = 1.0, size: CGFloat) {
        UIView.animate(withDuration: duration, animations: {
            self.frame.size.width = size
            
        })
    }
    
    func growVertical(withDuration duration: TimeInterval = 1.0, size: CGFloat) {
        UIView.animate(withDuration: duration, animations: {
            self.frame.size.height = size
            self.frame.origin.y = self.frame.origin.y - size
        })
    }
}
